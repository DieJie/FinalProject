/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Application;
import Model.Dosen;
import Model.Person;
import View.AddUserPanel;
import View.AdminPanel;
import View.seeUserPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author DivaPrasetya
 */
public class Handler_seeUser  implements ActionListener{
    seeUserPanel ViewSeeUser;
    Application model;
    AdminPanel AP;
    
    public Handler_seeUser(){
        AP = Handler_AdminPanel.ViewAdminPanel;
        this.model = Handler_Home.model;
        ViewSeeUser = new seeUserPanel();
        ViewSeeUser.ActionListener(this);
        ViewSeeUser.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        Object source = ae.getSource();
        if(source.equals(ViewSeeUser.getBtnOut())){
            ViewSeeUser.setVisible(false);
            AP.setVisible(true);
        }else if(source.equals(ViewSeeUser.getBtnSee())){
            String search = ViewSeeUser.getTextTFName();
            if(search.equals("")){
                JOptionPane.showMessageDialog(null, "Maaf anda belum menulis apapun", "Warning", JOptionPane.WARNING_MESSAGE);
            }else{
                for(Person p: model.getDaftarUser()){
                    System.out.println(p.getNama());
                }
                Person p = model.searchUser(search);
                if(null != p){
                    DefaultTableModel tdmodel = (DefaultTableModel) ViewSeeUser.getTbUser().getModel();
                    Object rowData[] = new Object[6];
                    rowData[0] = p.getUsername();
                    rowData[1] = p.getPassword();
                    rowData[2] = p.getNama();
                    if(p instanceof Dosen){
                        rowData[3] = "Dosen";
                    }else{
                        rowData[3] = "Mahasiswa";
                    }
                    rowData[4] = p.getNohp();
                    rowData[5] = p.getTtl();
                    tdmodel.addRow(rowData);
                }else{
                    JOptionPane.showMessageDialog(null, "Maaf data yang anda cari tidak ada", "Warning", JOptionPane.WARNING_MESSAGE);
                }
            }
        }
    }
}
