/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DivaPrasetya
 */
public class Dosen extends Person{
    int nidn ;
    private KelasTugasAkhir kelasTA;
    private List<KelasTugasAkhir> listKelasTA;
    private String topik;
    private static int  sid = 0 ;
    
    public Dosen(String username,String password,String nama,String nohp,String ttl){
        super(username,password,nama,nohp,ttl);
        nidn = 184220 + sid;
        sid++;
        listKelasTA = new ArrayList<KelasTugasAkhir>();
    }
    
    public void createKelompokTA(String topik,Dosen d){
        this.topik = topik;
        KelasTugasAkhir KTA = new KelasTugasAkhir(topik,d);
        listKelasTA.add(KTA);
        kelasTA = KTA;
    }

    public int getNidn() {
        return nidn;
    }

    public KelasTugasAkhir getKelasTA(){
        return kelasTA;
    }
    
}
