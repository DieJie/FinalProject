/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DivaPrasetya
 */
public class KelasTugasAkhir {
    private Dosen PemilikKTA;
    private List<Dosen> timDosen;
    private List<Mahasiswa> daftarMhsTA;
    String TopikTA;
    String KodeKelas;
    
    public KelasTugasAkhir(String topik, Dosen d){
        KodeKelas = "142"+Integer.toString(d.getNidn());
        PemilikKTA = d;
        setTopik(topik);
        timDosen = new ArrayList();
        daftarMhsTA = new ArrayList();
    }
    
    public void setTopik(String topik){
        TopikTA = topik;
    }
    
    public void addMahasiswa(Mahasiswa m){
        daftarMhsTA.add(m);
    }
    
    public void addDosen(Dosen d){
        timDosen.add(d);
    }
    
    public String getKodeKelas(){
        return KodeKelas;
    }

    public List<Dosen> getTimDosen() {
        return timDosen;
    }

    public List<Mahasiswa> getDaftarMhsTA() {
        return daftarMhsTA;
    }
    
    
}
